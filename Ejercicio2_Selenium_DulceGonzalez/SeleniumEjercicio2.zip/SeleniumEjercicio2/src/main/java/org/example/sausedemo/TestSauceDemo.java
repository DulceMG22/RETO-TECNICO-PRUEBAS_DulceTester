package org.example.sausedemo;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;

public class TestSauceDemo {

   private WebDriver driver;
    PageSauceDemo pageSauceDemo;


    @BeforeTest
    public void setUp() throws Exception{
        pageSauceDemo = new PageSauceDemo(driver);
        driver = pageSauceDemo.NavegadorConnection();
        pageSauceDemo.visit("https://www.saucedemo.com/");
        driver.manage().window().maximize();
    }

    @AfterTest
    public void TerminarCase () throws Exception{
        driver.quit();
    }

    @Test
    public void test () throws InterruptedException, IOException {
        pageSauceDemo.Login();
        pageSauceDemo.AgregarACarrito();
        pageSauceDemo.CheckOut();
        pageSauceDemo.finalizarCompra();

    }
}
