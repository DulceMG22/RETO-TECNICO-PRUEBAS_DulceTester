package org.example.sausedemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;


public class PageSauceDemo extends BaseSauceDemo {
    By botonLogin = By.id("login-button");
    By campoUser = By.id("user-name");
    By campoPass = By.id("password");
    By producto1 = By.id("add-to-cart-sauce-labs-bolt-t-shirt");
    By producto2 = By.id("add-to-cart-sauce-labs-bike-light");
    By producto3 = By.id("add-to-cart-sauce-labs-fleece-jacket");
    By carrito = By.id("shopping_cart_container");
    By checkout = By.id("shopping_cart_container");
    By firstname = By.xpath("//*[@id=\"first-name\"]");
    By lastname = By.xpath("//*[@id=\"last-name\"]");
    By postalCode = By.xpath("//*[@id=\"postal-code\"]");
    By btncontinue = By.xpath("//*[@id=\"continue\"]");
    By finish = By.id("finish");


    public PageSauceDemo(WebDriver driver) {
        super(driver);
    }

    public void Login () throws InterruptedException, IOException {
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        click(botonLogin);
        takeScreenShot("PaginaLogin");
        type("standard_user", campoUser); //datos correctos
        type("secret_sauce", campoPass); //Datos correctos
        takeScreenShot("PaginaLoginExitoso");
        click(botonLogin);
        Thread.sleep(5000);
        System.out.println("Se completa el login");

    }

    public void AgregarACarrito () throws InterruptedException, IOException {
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        takeScreenShot("PaginaInicioProductos");
        isDisplayed(carrito);
        click(producto1);
        click(producto2);
        click(producto3);
        takeScreenShot("ProductosSeleccionados");
        Thread.sleep(5000);
        System.out.println("Se agregan 3 productos al carrito");

    }

    public void CheckOut () throws InterruptedException, IOException {
        click(carrito);
        takeScreenShot("ProductosEnCarrito");
        Thread.sleep(5000);
        isDisplayed(checkout);
        click(checkout);
        System.out.println("realizar checkout");


    }

    public void finalizarCompra () throws InterruptedException, IOException {
        isDisplayed(firstname);
        takeScreenShot("PaginallenarDatos");
        Thread.sleep(5000);
        type("Dulce Maria", firstname);
        type("Gonzalez Arredondo", lastname);
        type("07810", postalCode);
        takeScreenShot("DatosCompletosCompra");
        click(btncontinue);
        click(finish);
        takeScreenShot("CompraFinalizada");
        Thread.sleep(5000);
        System.out.println("Finalizar compra");

    }
}
