package org.example.sausedemo;

import org.apache.commons.io.FileUtils; // Required for FileUtils

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;



public class BaseSauceDemo {
    public WebDriver driver;

    public BaseSauceDemo (WebDriver driver) {
        this.driver = driver;
    }

    public WebDriver NavegadorConnection() {
        driver = new ChromeDriver();
        return driver;
    }
    public  void visit(String url){
        driver.get(url);
    }

    public void type(String inputTest, By locator){
        driver.findElement(locator).sendKeys(inputTest);
    }

    public void click(By locator){
        driver.findElement(locator).click();
    }

    public Boolean isDisplayed(By locator){
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e){
            return false;
        }
    }

    public void takeScreenShot(String name) throws IOException {
        File image = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        File destinationFile = new File("src/test/evidences/img_" + name + ".jpg");
        FileUtils.copyFile(image, destinationFile);
    }

}
