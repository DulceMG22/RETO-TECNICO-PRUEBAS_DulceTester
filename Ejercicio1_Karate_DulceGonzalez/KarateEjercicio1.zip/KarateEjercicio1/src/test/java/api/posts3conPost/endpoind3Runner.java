package api.posts3conPost;

import com.intuit.karate.junit5.Karate;

class endpoind3Runner {
    
    @Karate.Test
    Karate testPost3() {
        return Karate.run("endpoind3").relativeTo(getClass());
    }    

}
