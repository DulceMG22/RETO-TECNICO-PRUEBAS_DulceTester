package api.posts2conGetId;

import com.intuit.karate.junit5.Karate;

class endpoind2Runner {
    
    @Karate.Test
    Karate testPost2() {
        return Karate.run("endpoind2").relativeTo(getClass());
    }    

}
