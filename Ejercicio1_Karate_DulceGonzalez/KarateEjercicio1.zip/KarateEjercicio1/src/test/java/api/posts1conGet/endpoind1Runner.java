package api.posts1conGet;

import com.intuit.karate.junit5.Karate;

class endpoind1Runner {
    
    @Karate.Test
    Karate testPost1() {
        return Karate.run("endpoind1").relativeTo(getClass());
    }    

}
