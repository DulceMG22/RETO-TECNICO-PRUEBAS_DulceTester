package api.posts4conPut;

import com.intuit.karate.junit5.Karate;

class endpoind4Runner {
    
    @Karate.Test
    Karate testPost4() {
        return Karate.run("endpoind4").relativeTo(getClass());
    }    

}
