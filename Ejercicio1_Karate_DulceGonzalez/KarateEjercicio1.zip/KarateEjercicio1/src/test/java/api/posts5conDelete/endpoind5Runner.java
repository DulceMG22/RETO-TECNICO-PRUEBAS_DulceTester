package api.posts5conDelete;

import com.intuit.karate.junit5.Karate;

class endpoind5Runner {
    
    @Karate.Test
    Karate testPost4() {
        return Karate.run("endpoind5").relativeTo(getClass());
    }    

}
